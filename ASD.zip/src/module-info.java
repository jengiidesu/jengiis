module ASD {
    requires java.sql;
    exports com.asd;
}
