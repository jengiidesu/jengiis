package com.asd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class YachtGame {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/yacht_game";
    private static final String USER = "root";
    private static final String PASS = "root";

    public static Connection connect() throws SQLException {
        return DriverManager.getConnection(DB_URL, USER, PASS);
    }

    public static void saveScore(int playerId, String category, int score) throws SQLException {
        String query = "INSERT INTO Score (player_id, category, score) VALUES (?, ?, ?)";
        try (Connection conn = connect();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, playerId);
            stmt.setString(2, category);
            stmt.setInt(3, score);
            stmt.executeUpdate();
        }
    }
}
