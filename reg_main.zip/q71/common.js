function dw(str) {
    document.write(str);
}

function br() {
    document.write("<br>");
}

function hr() {
    document.write("<hr>");
}