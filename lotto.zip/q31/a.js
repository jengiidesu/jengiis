function randomnum() {
    return Math.floor(Math.random() * 45) + 1;
}

function checkLotto() {
    // 사용자 입력값 가져오기
    var usernum = [
        parseInt(document.getElementById('num1').value),
        parseInt(document.getElementById('num2').value),
        parseInt(document.getElementById('num3').value),
        parseInt(document.getElementById('num4').value),
        parseInt(document.getElementById('num5').value),
        parseInt(document.getElementById('num6').value)
    ];

    // 유효성 검사
    if (usernum.length !== 6 || usernum.some(num => num < 1 || num > 45)) {
        document.getElementById('result').innerHTML = '모든 번호는 1에서 45 사이여야 합니다.';
        return;
    }

    // 중복 검사
    var userno = new Set(usernum);
    if (userno.size !== 6) {
        document.getElementById('result').innerHTML = '번호는 중복되지 않아야 합니다.';
        return;
    }

    // 랜덤 로또 번호 생성
    var lottonum = [];
    while (lottonum.length < 6) {
        var num = randomnum();
        if (!lottonum.includes(num)) {
            lottonum.push(num);
        }
    }

    // 보너스 번호 생성
    var b;
    do {
        b = randomnum();
    } while (lottonum.includes(b));

    // 맞춘 번호 개수 계산
    var match = usernum.filter(num => lottonum.includes(num)).length;

    // 결과 표시
    var talk = '추첨된 번호: ' + lottonum.join(', ') + '<br>';
    talk += '보너스 번호: ' + b + '<br>';
    talk += '맞춘 번호 갯수: ' + match + '<br>';

    var messeage;
    if (match === 6) {
        messeage = '1등에 당첨되셨습니다!';
    } else if (match === 5) {
        messeage = '3등에 당첨되셨습니다!'; 
    }
    else if (match === 4) {
        messeage = '4등에 당첨되셨습니다!';
    } else if (match === 3) {
        messeage = '5등에 당첨되셨습니다!';
    } else {
        messeage = '꽝!!! 다음 기회에';
    }
    for(var match=0;match<6;match=match+1){
        if(b==usernum[match]){
            messeage = '2등에 당첨되셨습니다!';
        }
    }
    talk += messeage;
    document.getElementById('result').innerHTML = talk;
}
