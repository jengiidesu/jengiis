package com.peisia.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.peisia.dto.GuestDto;
import com.peisia.service.GuestService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@RequestMapping("/guest/*")
@AllArgsConstructor
@Controller
public class GuestController {

    private GuestService service;

	@GetMapping("/getList")
	public void getList(@RequestParam(value="Page", defaultValue="1") int Page, Model model) {
		model.addAttribute("list",service.getList(Page));
		model.addAttribute("Page", Page);
	}

    @GetMapping({"/read", "/modify"})
    public void read(@RequestParam("bno") Long bno, Model model) {
        log.info("��Ʈ�ѷ� ==== �۹�ȣ ==============="+bno);
        model.addAttribute("read", service.read(bno));
    }

    @GetMapping("/del")
    public String del(@RequestParam("bno") Long bno) {
        log.info("��Ʈ�ѷ� ==== �۹�ȣ ==============="+bno);
        service.deleteAndRearrangeBno(bno.intValue()); // �޼��� ȣ��
        return "redirect:/guest/getList"; 
    }

    @PostMapping("/write")
    public String write(GuestDto dto) {
        service.write(dto);
        return "redirect:/guest/getList"; 
    }   

    @GetMapping("/write")
    public void write() {
    }

    @PostMapping("/modify")
    public String modify(GuestDto dto) {
        service.modify(dto);
        return "redirect:/guest/getList";
    }
    
    
    
}
