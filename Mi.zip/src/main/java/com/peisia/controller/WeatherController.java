package com.peisia.controller;

import java.net.URI;
import java.net.URISyntaxException;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.peisia.service.GuestService;
import com.peisia.wDto.KWeatherDto;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@RequestMapping("/weather/*")
@AllArgsConstructor
@Controller
public class WeatherController {

    private GuestService service;

    @GetMapping("/w")                    
    public void w(Model m) {  // Model �Ķ���� �߰�                 
        String API_KEY = "TDf%2Fho9nOMC2Ho71ocCWLwhwgKl9KBhSyyX67Pylaw%2BN0V7GQsIt%2B7UaJQsN9X%2FrpsIc%2FJJR%2Bltqo30nKyUXjA%3D%3D";                
        String API_URL = "http://apis.data.go.kr/1360000/AsosDalyInfoService/getWthrDataList?numOfRows=10&pageNo=1&dateCd=DAY&startDt=20230220&endDt=20230220&stnIds=108&dataCd=ASOS&dataType=JSON&serviceKey=" + API_KEY;                
        RestTemplate restTemplate = new RestTemplate();                
                        
        URI uri = null;                
        try {                
            uri = new URI(API_URL);             
        } catch (URISyntaxException e) {                
            e.printStackTrace();            
        }                
                        
        String s = restTemplate.getForObject(uri, String.class);                 
        log.info("====== �츮���� ���� �� ������? " + s);                

        KWeatherDto kw = restTemplate.getForObject(uri, KWeatherDto.class); 
        log.info("==== json ==== : �츮���� ���� �� ������? : " + kw.response.body.dataType);

        String location = kw.response.body.items.item.get(0).stnNm;
        String tMin = kw.response.body.items.item.get(0).minTa;
        String tMax = kw.response.body.items.item.get(0).maxTa;
        String ddara = String.format("==== json ==== : ������ �����Դϴ�~ ���� %s �� ��������� %s �� �ְ� ����� %s �����ϴ�.", location, tMin, tMax);
        log.info(ddara);
        
        // Model�� �� �߰�
        m.addAttribute("location", location);
        m.addAttribute("tMin", tMin);
        m.addAttribute("tMax", tMax);
    }                            
}
