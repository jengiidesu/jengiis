
package com.peisia.wDto;

import javax.annotation.processing.Generated;

@Generated("jsonschema2pojo")
public class Header {

    public String resultCode;
    public String resultMsg;

}
