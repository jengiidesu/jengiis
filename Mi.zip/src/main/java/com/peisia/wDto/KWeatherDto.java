
package com.peisia.wDto;

import javax.annotation.processing.Generated;

@Generated("jsonschema2pojo")
public class KWeatherDto {

    public Response response;

}
