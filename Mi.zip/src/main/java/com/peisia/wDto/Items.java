
package com.peisia.wDto;

import java.util.List;

import javax.annotation.processing.Generated;

@Generated("jsonschema2pojo")
public class Items {

    public List<Item> item;

}
