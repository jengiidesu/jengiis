
package com.peisia.wDto;

import javax.annotation.processing.Generated;

@Generated("jsonschema2pojo")
public class Body {

    public String dataType;
    public Items items;
    public Integer pageNo;
    public Integer numOfRows;
    public Integer totalCount;

}
