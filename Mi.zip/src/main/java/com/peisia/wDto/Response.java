
package com.peisia.wDto;

import javax.annotation.processing.Generated;

@Generated("jsonschema2pojo")
public class Response {

    public Header header;
    public Body body;

}
