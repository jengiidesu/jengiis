// 버튼 클릭 시 이루어 질 명령들
function rpcButtonClick(userRpc) {
    var resultDiv = document.getElementById("result");
    // 결과값을 초기화시켜줌
    resultDiv.innerHTML = "";
// 컴퓨터의 가위바위보 결과를 계산 하는 식
    var comRpc = Math.floor(Math.random() * 9 + 1);
    if (comRpc == 1) {
        comRpc = "가위";
    } 
    else if (comRpc == 4) {
        comRpc = "바위";
    }
    else if (comRpc == 7) {
        comRpc = "보";
    }
    else if (comRpc == 2) {
        comRpc = "가위";
    }
    else if (comRpc == 5) {
        comRpc = "바위";
    }
    else if (comRpc == 8) {
        comRpc = "보";
    }
    else if (comRpc == 3) {
        comRpc = "가위";
    }
    else if (comRpc == 6) {
        comRpc = "바위";
    }
    else if (comRpc == 9) {
        comRpc = "보";
    }
// 무엇을 냈는지 이미지로 표현
    const imageFiles = {
        "가위": "scissors.jpg",
        "바위": "rock.jpg",
        "보": "paper.jpg"
    };
// 나와 컴퓨터가 낸 것에 대한 이미지 파일을 지정하기 위한 함수
    var userImage = imageFiles[userRpc];
    var comImage = imageFiles[comRpc];
// 나와 컴퓨터가 낸 것이 무엇인지 보여줌
    resultDiv.innerHTML += "<p>유저: <img src='" + userImage + "' alt='" + userRpc + "'></p>";
    resultDiv.innerHTML += "<p>컴퓨터: <img src='" + comImage + "' alt='" + comRpc + "'></p>";
// 각자 낸 것에 대해 비교하며 결과를 계산함
    var winDrawLose = "";
    switch(userRpc) {
        case "가위":
            switch(comRpc) {
                case "가위":
                    winDrawLose = "DRAW";
                    break;
                case "바위":
                    winDrawLose = "패배";
                    break;
                case "보":
                    winDrawLose = "승리";
                    break;
            }
            break;
        case "바위":
            switch(comRpc) {
                case "가위":
                    winDrawLose = "승리";
                    break;
                case "바위":
                    winDrawLose = "DRAW";
                    break;
                case "보":
                    winDrawLose = "패배";
                    break;
            }        
            break;
        case "보":
            switch(comRpc) {
                case "가위":
                    winDrawLose = "패배";
                    break;
                case "바위":
                    winDrawLose = "승리";
                    break;
                case "보":
                    winDrawLose = "DRAW";
                    break;
            }        
            break;
    }
// 결과를 글자로 보여줌
    resultDiv.innerHTML += "결과: " + winDrawLose + "";
}